#include<stdio.h>
int trianglePattern(int n)
{
    int c,k,space,count=1;
    space=1;
    for(c=n;c>=1;c--)
    {
        for(k=1;k<space;k++)
         printf(" ");
        for(k=1;k<=c;k++)
        {
            printf("*");
            if(c>1&&count<c)
            {
                printf(" ");
                count++;
            }
        }
        printf("\n");
        space++;
        count=1;
    }
    return 0;
}
void main()
{
    int n;
    printf("enter the number of rows");
    scanf("%d",&n);
    trianglePattern(n);
}

