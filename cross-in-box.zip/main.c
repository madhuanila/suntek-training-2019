#include <stdio.h>

int cross_in_box(int N)
{
    int i, j;
    for(i=1; i<=N; i++)
    {
        for(j=1; j<=N; j++)
        {
            if(i==1 || i==N || j==1 || j==N || i==j || (i==j+2 || j==i+2))
            {
                printf("*");
            }
            else
            {
                printf(" ");
            }
        }
        printf("\n");
    }

    return 0;
}
void main()
{
    int N;
    printf("Enter number of rows: ");
    scanf("%d", &N);
    cross_in_box(N);
}