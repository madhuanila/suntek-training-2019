#include<stdio.h>
int reverse(int n)
{
    int r,sum;
    while(n!=0)
    {
       r=n%10;
       sum=sum*10+r;
       n=n/10;
    }
    return sum;
}
void main()
{
    int n,rev;
    printf("enter the value of n:");
    scanf("%d",&n);
    rev=reverse(n);
    printf("%d is the reverse of given number",rev);
}