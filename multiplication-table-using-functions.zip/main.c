#include<stdio.h>
void table(int num,int limit)
{
    int i;
    for(i=1;i<=limit;i++)
    {
        printf("%d * %d = %d\n",num,i,(num*i));
    }
}
int main()
{
    int num,limit;
    printf("Enter the number:");
    scanf("%d",&num);
    printf("Enter the limit:");
    scanf("%d",&limit);
    table(num,limit);
    return 0;
}